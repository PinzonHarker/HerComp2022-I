// Declaratio
#pragma once
#include <vector>
#include <iostream>

double mean(const std::vector<double> & data);
std::vector<double> vectori(const int N);